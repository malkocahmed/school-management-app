var tabela = null;

function nacrtaj(){
    var mojDiv = document.getElementById("zatabelu");
    var unos = document.getElementById("unos");
     tabela = new CommitTabela(mojDiv,unos.value);
}
function dodajKomit(){
    var broj = document.getElementById("kbroj");
    var link = document.getElementById("klink"); 
    tabela.dodajCommit(broj.value,link.value);  

}
function editujKomit(){
    var red = document.getElementById("ebrojr");
    var kolona = document.getElementById("ebrojk");
    var link = document.getElementById("elink");
    tabela.editujCommit(red.value,kolona.value,link.value);
}
function obrisiKomit(){
    var red = document.getElementById("bred");
    var kolona = document.getElementById("bkolone"); 
    tabela.obrisiCommit(red.value,kolona.value);
}
