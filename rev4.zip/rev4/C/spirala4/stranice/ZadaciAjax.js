 /*Zadatak 8*. 
Napravite modul ZadaciAjax
Metode dajXML, dajCSV i dajJSON prave GET zahtjev koristeći XMLHttpRequest na url iz prethodnog
zadatka. Kada se dobije odgovor sa servera pozovite callbackFn i kao parametar proslijedite tijelo odgovora
sa servera. Ukoliko se pozove više metoda, a odgovor nije stigao pozovite callbackFn sa parametrom
{greska:”Već ste uputili zahtjev”}. Ako odgovor za neku od metoda ne stigne u roku od 2 sekunde prekinite
taj zahtjev.
 */
//moze se preobati preko forme probni.html

var ZadaciAjax = (function(){
    var ajax = null;

    function primanjeZahtjeva(callbackFn,vrsta) {
        ajax.ontimeout = function(e) {
            console.log('abort');
            ajax.abort();
            
        }


        ajax.onreadystatechange = function () { 
            
            if(ajax.readyState == 4) {
            if(ajax.status == 200) {
                console.log('Odgovor: '+ajax.responseText);

                if(vrsta == 'json') {
                    callbackFn(ajax.responseText);
                }
                else if(vrsta == 'xml') {
                    callbackFn('<xmp>'+ajax.responseText+'</xmp>');
                }
                else {
                    var odg = ajax.responseText;
                    odg = odg.split('\n').join('<br>');
                    callbackFn(odg);
                }
            }
            else {
                var parametar = {'greska':'Vec ste uputili zahtjev'};
                console.log("greska");
                callbackFn(JSON.stringify(parametar));
            }
        }
            
        }
    }

    var konstruktor = function(callbackFn){
        
    return {
    dajXML:function(){
        ajax = new XMLHttpRequest();
        primanjeZahtjeva(callbackFn,'xml');   

        ajax.open('GET','http://localhost:8080/zadaci',true);
        ajax.timeout = 2000;
        ajax.setRequestHeader('Accept','application/xml');       
        ajax.send();
    },
    dajCSV:function(){
        ajax = new XMLHttpRequest();
        primanjeZahtjeva(callbackFn,'csv'); 
        ajax.open('GET','http://localhost:8080/zadaci ',true);
        ajax.timeout = 2000;
        ajax.setRequestHeader('Accept','text/csv');
        ajax.send();
    },
    dajJSON:function(){
        ajax = new XMLHttpRequest();
        primanjeZahtjeva(callbackFn,'json'); 
        ajax.open('GET','http://localhost:8080/zadaci ',true);
        ajax.timeout = 2000;
        ajax.setRequestHeader('Accept','application/json');
        ajax.send();
        
    }
    }
    }
    return konstruktor;
    }());