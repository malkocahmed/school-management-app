function provjera(){
    var ime1 = document.getElementById("username");
    var password1 = document.getElementById("password");
    var poruka = document.getElementById("poruka");
    var validacija = new Validacija(poruka);
    validacija.ime(ime1);
    validacija.password(password1); 
    
}