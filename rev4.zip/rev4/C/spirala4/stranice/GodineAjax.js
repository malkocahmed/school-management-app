 /*Zadatak 6.
Napravite modul GodineAjax.
Pozivom konstruktora pravi se zahtjev koristeći XMLHttpRequest na http://localhost:8080/godine. U
divSadrzaj upisuju se godine koje izgledaju kao na spirali 1, a podaci unutar godine su naziv godine, naziv
repozitorija vjezbi i naziv repozitorija spirale.
Metoda osvjezi ponovo šalje zahtjev i osvježava sadržaj diva divSadrzaj.
 */


var GodineAjax = (function(){    
    var ajax = null;

    function upisiPodatke(ajax,divSadrzaj) {
        ajax.onreadystatechange = function () {
            if(ajax.readyState == 4 && ajax.status == 200) {
                divSadrzaj.innerHTML = '';
                nizJsona = ajax.responseText;
                nizJsona = JSON.parse(nizJsona);
                for(var i in nizJsona) {
                var kockica = document.createElement('kocka'+i);
                kockica.setAttribute('class','kockice');     
                kockica.appendChild(document.createElement('br')); 
                kockica.appendChild(document.createElement('br')); 
                kockica.appendChild(document.createElement('br'));        
                kockica.appendChild(document.createTextNode('Naziv godine: '+ nizJsona[i].nazivGod));
                kockica.appendChild(document.createElement('br'));      
                kockica.appendChild(document.createTextNode('Naziv repozitorija: '+ nizJsona[i].nazivRepVje));
                kockica.appendChild(document.createElement('br'));
                kockica.appendChild(document.createTextNode('Naziv repozitorija: '+nizJsona[i].nazivRepSpi));
                divSadrzaj.appendChild(kockica);
                } 
            }
        }    
    }

var konstruktor = function(divSadrzaj){    
    ajax = new XMLHttpRequest();
    upisiPodatke(ajax,divSadrzaj);
    ajax.open("GET", "http://localhost:8080/godine", true);
    ajax.setRequestHeader('Content-Type','application/json');
    ajax.send();

return {
osvjezi:function(){
    ajax = new XMLHttpRequest();
    upisiPodatke(ajax,divSadrzaj);    
    ajax.open("GET", "http://localhost:8080/godine", true);
    ajax.setRequestHeader('Content-Type','application/json');
    ajax.send();
}
}
}
return konstruktor;
}());
