function provjera(){
    var naziv = document.getElementById("naziv");
    var rvjezbe = document.getElementById("rvjezbe");
    var rspirale = document.getElementById("rspiral");
    var poruka = document.getElementById("poruka");
    var validacija = new Validacija(poruka);
    var prva = validacija.godina(naziv);
    var druga = validacija.repozitorij(rvjezbe,/[a-z]/m);
    var treca = validacija.repozitorij(rspirale,/[a-z]/m);
    if(prva == true && druga == true && treca==true) return true;
    return false;
    
}
var godine = null;

function poziv(){
    console.log('poziv');
    var div = document.getElementById("glavniSadrzaj");   
    godine= new GodineAjax(div); 
}
function osvjeziG() {
    if(godine != null)
    godine.osvjezi();
}