var CommitTabela=(function(){
    //lokalne variable idu ovdje
  
    var brRedova = 0;
    var redSmaxom = 0;
    var maxSpan = 1;

    //fja
    function nadjiMax(){
        var table = document.getElementById('tabela');
        var max = 0;
        var red = 0;
        for(var i=1;i<table.rows.length;i++) {
            if(max < table.rows[i].cells.length) {
                max = table.rows[i].cells.length;
                red = i;
            }
        }
       maxSpan = max;
       redSmaxom = red;
    }     

    //fja
    function prosiriOstale(){
        var tabela = document.getElementById('tabela');
        for(var i = 1; i < tabela.rows.length; i++){
            var kol = tabela.rows[i].cells.length;
            if( i != redSmaxom && tabela.rows[i].cells[parseInt(kol)-1].innerHTML != "" && kol != maxSpan){
                var cell =tabela.rows[i].insertCell(kol);
                var span = parseInt(maxSpan) - parseInt(kol);
                cell.setAttribute('colSpan',span);
            }
            else if( i != redSmaxom && tabela.rows[i].cells[parseInt(kol)-1].innerHTML == ""){
                kol = parseInt(kol)-1;
                var cell =tabela.rows[i].cells[kol];
                var span = parseInt(maxSpan) - parseInt(kol);
               if(kol != maxSpan)
                cell.setAttribute('colSpan',span);
            }
        }
    }


    var konstruktor=function(divElement,brojZadataka){
    var tbl  = document.createElement('table');
    tbl.setAttribute('id','tabela');
    brRedova = brojZadataka-2;
    for(var i = 0; i < parseInt(brojZadataka); i++){
        var row = tbl.insertRow(i);
        for(var j = 0; j < 2; j++){           
                var cell = row.insertCell(j);
                if(i == 0 && j == 1) {
                cell.setAttribute("id","komit");
                cell.appendChild(document.createTextNode('Commiti'));
                }
                else if(j == 0 && i != 0)
                cell.appendChild(document.createTextNode('Zadatak '+i));
                else if(i == 0 && j== 0)
                cell.appendChild(document.createTextNode('Zadaci'));

                cell.colSpan='1';                          
        }
    }    
    divElement.appendChild(tbl);

    return{
    dodajCommit:function(rbZadatka,url){
        if(rbZadatka > brRedova || rbZadatka < 0) return -1;
        var tabela = document.getElementById('tabela');  
        var red = parseInt(rbZadatka)+1; 
        var zadnjaKolona = tabela.rows[red].cells.length;
        zadnjaKolona = parseInt(zadnjaKolona)-1;
        if(tabela.rows[red].cells[zadnjaKolona].innerHTML == ""){
        this.editujCommit(rbZadatka,zadnjaKolona,url);
        
        if(tabela.rows[red].cells[zadnjaKolona].colSpan != "1") tabela.rows[red].cells[zadnjaKolona].colSpan = "1";
        }
        else {
        var gdje = parseInt(tabela.rows[red].cells.length);     
        var cell =tabela.rows[red].insertCell(gdje);
        cell.innerHTML = '<a href="'+url+'">'+gdje+'</a>';      
        gdje = parseInt(tabela.rows[red].cells.length)-1;        
        }
        nadjiMax();
        document.getElementById('komit').colSpan = maxSpan;
        prosiriOstale();       
       
    },
    editujCommit:function(rbZadatka,rbCommita,url){
        var tabela = document.getElementById('tabela');
        var red = parseInt(rbZadatka)+1;
        if(rbZadatka > brRedova || rbZadatka < 0 || rbCommita <= 0 || rbCommita > tabela.rows[red].cells.length ) return -1;
        
       
        var kol = rbCommita;
        tabela.rows[red].cells[kol].innerHTML = '<a href="'+url+'">'+rbCommita+'</a>';
    
    },
    obrisiCommit:function(rbZadatka,rbCommita){
        var tabela = document.getElementById('tabela');
        if(rbZadatka > brRedova || rbZadatka < 0 || rbCommita <= 0 || rbCommita > tabela.rows[rbZadatka].cells.length ) return -1;
              
        var red = parseInt(rbZadatka)+1; 
        if(tabela.rows[red].cells[rbCommita].innerHTML != "")  tabela.rows[red].deleteCell(rbCommita);
        for(var i = 1; i <  tabela.rows[red].cells.length; i++ ){
        if(tabela.rows[red].cells[i].innerHTML != "") {
        var str = tabela.rows[red].cells[i].innerHTML;
        var n = str.indexOf('>');
        var s = str.substr(0,parseInt(n));
        s += '> '+i+'</a>';
        tabela.rows[red].cells[i].innerHTML = s;
        nadjiMax();
        prosiriOstale();
        }
        }
    }
    }
    }
    return konstruktor;
    }());

 
   
 

