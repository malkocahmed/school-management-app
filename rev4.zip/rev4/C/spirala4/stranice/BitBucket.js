var BitBucket = (function() {


    var konstruktor = function() {


        return {
        ucitaj:function(nazivRepSpi,nazivRepVje,callback) {
            var lista = [{"imePrezime":"Tarik Tarkovic","index":17338},
                         {"imePrezime":"Meho Mehic","index":17369},
                         {"imePrezime":"Petar Petric","index":17354},
                         {"imePrezime":"Marko Markovic","index":13213},
                         {"imePrezime":"Marko Markovic","index":13113},
                         {"imePrezime":"Petar Petric","index":17353},
                         {"imePrezime":"Marko Markovic","index":13333},
                         {"imePrezime":"Marko Markovic","index":1343},
                         {"imePrezime":"Meho Mehic","index":17339},
                         {"imePrezime":"Petar Petric","index":17654}];
            document.getElementsByTagName('input')[2].disabled = false;
            callback(lista);

        }
        }
        
    }
    return konstruktor;
}());