var ZadaciLoadPrvi = (function() {

    function zadatkeCekam(ajax) {
        ajax.onreadystatechange = function () {
            if(ajax.readyState == 4 && ajax.status == 200) { 
              var select = document.getElementById('sZadatak');
              select.innerHTML ="";
              var niz = JSON.parse(ajax.responseText);
              console.log('voa');
              for(el in niz) {
              var opt = document.createElement('option');   
              console.log(niz[el]+'hej');       
              opt.textContent = niz[el].naziv;
              opt.value = niz[el].naziv;              
              select.appendChild(opt);
              }
             
            }
        }
    }


    var konstruktor = function() {

        return {
            popuniZadatkeNaLoad:function(v) {
                ajax = new XMLHttpRequest();
                ajax.open('GET','http://localhost:8080/vjezba?ime='+v,true);   
                ajax.setRequestHeader('Accept','application/json');
                ajax.send();
                zadatkeCekam(ajax);
             }
        }
    }
    return konstruktor;
}());