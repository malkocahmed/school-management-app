var zadaci = null;

function pozivanjeZadaciAjax() {
zadaci = new ZadaciAjax(function(upis) {
    var div = document.getElementById("upisi");
    div.innerHTML += upis;
});
/*zadaci.dajCSV();
zadaci.dajJSON();
zadaci.dajCSV();
zadaci.dajJSON();
zadaci.dajCSV();
zadaci.dajJSON();
zadaci.dajCSV();
zadaci.dajJSON();*/

}

function prikaziJSON() {
    zadaci.dajJSON();
}

function prikaziXML() {
    zadaci.dajXML();
}

function prikaziCSV() {
    zadaci.dajCSV();
}