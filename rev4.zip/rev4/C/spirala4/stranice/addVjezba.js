function provjera(){
    var godina = document.getElementById("sGodine");
    var poruka = document.getElementById("poruka");
    var validacija = new Validacija(poruka);
    if(!validacija.godina(godina)) return false;
    return true;
    
}
function pregledaj(){
    var unos = document.getElementById("unos");
    var godina = document.getElementById("godina");
    var poruka = document.getElementById("poruka1");
    var validacija = new Validacija(poruka);
    var n = validacija.naziv(unos);
    var g = validacija.godina(godina);
    if(n == true && g == true) return true;
    return false;
    

}
function pozoviSve() {
    var g = new PopunjavanjeAjax();
    g.dajGodine();     
    g.dajVjezbe();
  //  g.dajZadatke();
}

function zadaci() {
    var g = new PopunjavanjeAjax();
    g.dajZadatke();
}

function postaviAction() {
    var select = document.getElementsByName('sVjezbe')[1].value;
    document.getElementsByName('fPoveziZadatak')[0].action = 'http://localhost:8080/vjezba/:'+select+'/zadatak';
    return true;
}