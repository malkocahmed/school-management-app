var Validacija=(function(){
    //lokalne variable idu ovdje
    var ime = null;     
    var godina = null;
    var repozitorij = null;
    var index = null;
    var naziv = null;
    var password = null;
    var url = null;

    function ispis(divElementPoruke,ispis,inputElement){
      if(divElementPoruke.innerHTML == ""){
          divElementPoruke.innerHTML = "Sljedeća polja nisu validna:"+ispis+"!";
       }
       else{
         var citav = divElementPoruke.innerHTML;
         var vel = citav.length;
         var zadnjeSlovo = citav.substring(vel-1,vel);
        
         citav = citav.substring(0,vel-1);
         divElementPoruke.innerHTML = citav;   
        divElementPoruke.innerHTML += ","+ispis+"!";
       } 
       inputElement.style.backgroundColor = "orangered";
      }


    var konstruktor=function(divElementPoruke){
    divElementPoruke.innerHTML ="";
    return{
    ime:function(inputElement){
        /*Validno ime predstavlja maksimalno četri riječi koje počinju velikim slovom, svaka riječ ne
          smije biti kraća od dva slova. Riječi mogu biti odvojene razmakom ili crticom. Unutar riječi
          se može pojaviti apostrof ali nikada odmah do drugog apostrofa*/
        var regex = /^([A-Z]{1}([a-z]|'(?!')){1,}([\s|-]|[a-zA-Z]?$){1}){1,4}$/m; 
        ime = regex.test(inputElement.value);
        if(ime == false){
          ispis(divElementPoruke,"ime",inputElement);
          return false;
        }
        else {
          inputElement.style.backgroundColor = "white";
          return true;
        }
         
         
    },
    godina:function(inputElement){
      /*  Validna godina predstavlja string oblika 20AB/20CD gdje je CD broj za jedan veći od AB*/
      var regex = /^20[0-9]{2}\/20[0-9]{2}$/m ;
      var jelDobarFormat = regex.test(inputElement.value);
      var prviBr = inputElement.value.substring(2,4);
      var drugiBr = inputElement.value.substring(7,9); //end
      if(parseInt(drugiBr) > parseInt(prviBr) && jelDobarFormat == true) godina= true;
      else godina = false;
      if(godina == false){
        ispis(divElementPoruke,"godina",inputElement);
        return false;
        }
        else  {
          inputElement.style.backgroundColor = "white";
          return true;
        }
      
    },
    repozitorij:function(inputElement,regex){
      /*  Validan repozitorij predstavlja string koji zadovoljava regex iz parametra*/
      repozitorij = regex.test(inputElement.value); // ne mora bit citava rijec, treba drugacije provjeravat onda??
      if(repozitorij == false) {
        ispis(divElementPoruke,"repozitorij",inputElement);
        return false;
        }
        else {
          inputElement.style.backgroundColor = "white";
          return true;
        } 
    },
    index:function(inputElement){
        /*Validan index je petocifren pozitivan broj gdje su prve dvije cifre od 14 do 20*/
        var regex =/^(14|15|16|17|18|19|20)[0-9]{3}$/m;
        index = regex.test(inputElement.value);
        if(index == false){
          ispis(divElementPoruke,"index",inputElement);
          return false;
        }
        else {
          inputElement.style.backgroundColor = "white";
          return true;
        }
    },
    naziv:function(inputElement){
        /*Validan naziv je string koji počinje slovima, a završava brojem ili malim slovom. Ne može
          biti kraći od 3 slova i može sadržavati brojeve, slova i sljedeće znakove \ / - “ ‘ ! ?
          : ; , */
          var regex = /^([a-zA-Z]([0-9]|(\/|\\|-|"|'|!|\?|:|;|,)|[a-z])+(\d|[a-z]))$/m;
          naziv = regex.test(inputElement.value);
          if(naziv == false){
            ispis(divElementPoruke,"naziv",inputElement);
            return false;
            }
            else {
              inputElement.style.backgroundColor = "white";
              return true;
            }
    },
    password:function(inputElement){
        /*Validan password sadrži minimalno osam znakova u kojima mora biti bar dvoje od
          sljedećeg: veliko slovo, malo slovo ili broj. Ostali znakovi su zabranjeni. */
          var regex =/^((?=.*[a-z])(?=.*[A-Z])|(?=.*\d)(?=.*[a-z])|(?=.*\d)(?=.*[A-Z]))[a-zA-Z\d]{8,}$/m;
          password = regex.test(inputElement.value);
          if(password == false) {
            ispis(divElementPoruke,"password",inputElement);
            return false;
          }
          else {
            inputElement.style.backgroundColor = "white";
            return true;
          }
        
    },
    url:function(inputElement){
      /* Validan url ima format protokol://host/putanja?parametri. Boldirani dijelovi su obavezni,
         a ostali dopušteni. Protokol može biti http, https, ftp ili ssh. Host se sastoji od 1 ili više
         riječi odvojenih tačkama, ne može počinjati ili završavati tačkom. Putanja sadrži jednu ili
         više riječi odvojenih sa slash znakom. Ukoliko postoje parametri na kraju se dodaje “?”.
         Parametri imaju oblik rijec=rijec&rijec=rijec. Riječ može sadržavati samo mala slova
         engleske abecede, brojeve i crticu -, ne može počinjati niti završavati crticom.
         */
        var regex = /^((http|https|ftp|ssh):\/\/([a-z0-9]+[\-|\.]*)*[a-z0-9]+(\/([a-z0-9]+[-]*(\/(?!\/))*[-]*)*[a-z0-9]+){0,1}(\?(([a-z0-9]+[-]*)*[a-z0-9]+\=([a-z0-9]+[-]*)*[a-z0-9]+\&([a-z0-9]+[-]*)*[a-z0-9]+\=([a-z0-9]+[-]*)*[a-z0-9]+)){0,1})$/m;
        url = regex.test(inputElement.value);
        if(url == false) { 
          ispis(divElementPoruke,"url",inputElement);
          return false;
          
        }
        else {
          inputElement.style.backgroundColor = "white";
          return true;
      }
    }
    }
  }
    
    return konstruktor;
    }());