var PopunjavanjeAjax =(function() {
  
    
    function godineCekam(ajax) {
        ajax.onreadystatechange = function () {
            if(ajax.readyState == 4 && ajax.status == 200) {              
            
              var select = document.getElementsByName('sGodine')[0];
              if(select != null) {
              var niz = JSON.parse(ajax.responseText);
              for(el in niz) {
              var opt = document.createElement('option');
              opt.textContent = niz[el].nazivGod;
              opt.value = niz[el].nazivGod;
              select.appendChild(opt);
             }
            }
             var select = document.getElementsByName('sGodine')[1];
             if(select != null) {
             var niz = JSON.parse(ajax.responseText);
             for(el in niz) {
             var opt = document.createElement('option');
             opt.textContent = niz[el].nazivGod;
             opt.value = niz[el].nazivGod;
             select.appendChild(opt);
            }
        }
        var god =document.getElementsByName('sGodina')[0];
        if(god != null) {
        var niz = JSON.parse(ajax.responseText);
        for(el in niz) {
        var opt = document.createElement('option');
        opt.textContent = niz[el].nazivGod;
        opt.value = niz[el].nazivGod;
        god.appendChild(opt);
        }
            }
    }

}
    }

    function vjezbeCekam(ajax)
    {

        ajax.onreadystatechange = function () {
            if(ajax.readyState == 4 && ajax.status == 200) { 
                var select = document.getElementsByName('sVjezbe')[0];
                var niz = JSON.parse(ajax.responseText);
                for(el in niz) {
                var opt = document.createElement('option');          
                opt.textContent = niz[el].naziv;
                opt.value = niz[el].naziv;              
                select.appendChild(opt);
               }
               var select = document.getElementsByName('sVjezbe')[1];
                var niz = JSON.parse(ajax.responseText);
                for(el in niz) {
                var opt = document.createElement('option');          
                opt.textContent = niz[el].naziv;
                opt.value = niz[el].naziv;              
                select.appendChild(opt);
               }
               var selektovana = document.getElementsByName('sVjezbe')[1].value;
               var v =new ZadaciLoadPrvi();
               v. popuniZadatkeNaLoad(selektovana);
            }
        }

    }    

    function zadatkeCekam(ajax) {
        ajax.onreadystatechange = function () {
            if(ajax.readyState == 4 && ajax.status == 200) { 
              var select = document.getElementById('sZadatak');
              select.innerHTML ="";
              var niz = JSON.parse(ajax.responseText);
              console.log('voa');
              for(el in niz) {
              var opt = document.createElement('option');   
              console.log(niz[el]+'hej');       
              opt.textContent = niz[el].naziv;
              opt.value = niz[el].naziv;              
              select.appendChild(opt);
              }
             
            }
        }
    }

  


    var konstruktor = function(){
         
        
        return {
         dajGodine:function() {
            
            var ajax = new XMLHttpRequest();
            
            ajax.open('GET','http://localhost:8080/godine',true);   
            ajax.send();
            godineCekam(ajax);
            
         },
         dajZadatke:function() {
             //2c
            var ajax = new XMLHttpRequest();
            var e = document.getElementsByName('sVjezbe')[1];
            var ime = e.options[e.selectedIndex].value;
            ajax.open('GET','http://localhost:8080/vjezba?ime='+ime,true);   
            ajax.setRequestHeader('Accept','application/json');
            ajax.send();
            zadatkeCekam(ajax);
             
         },
         dajVjezbe:function() {
            var ajax = new XMLHttpRequest();
            
            ajax.open('GET','http://localhost:8080/vjezbe',true);   
            ajax.setRequestHeader('Accept','application/json');
            ajax.send();
            vjezbeCekam(ajax);
           
         },
        

        }
    }
        return konstruktor;
}());