var StudentiAjax = (function() {

    var konstruktor = function() {


        return{
            pozovi:function(lista) {
                //kreiranje jsona
                var g = document.getElementById('sGodina').value;
                var json = {godina:g, studenti:lista};



                var ajax = new XMLHttpRequest();
                ajax.open('POST','http://localhost:8080/student',true);
                ajax.setRequestHeader('Content-Type','application/json');
                ajax.send(JSON.stringify(json));



                ajax.onreadystatechange = function () {
                    if(ajax.readyState == 4 && ajax.status == 200) {  
                    alert(ajax.responseText);
                    }
                }
            }
        }
    }
    return konstruktor;
}());