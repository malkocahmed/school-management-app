function provjera(){
    var naziv = document.getElementById("query");
    var poruka = document.getElementById("poruka");
    var validacija = new Validacija(poruka);
    validacija.naziv(naziv);
    
}