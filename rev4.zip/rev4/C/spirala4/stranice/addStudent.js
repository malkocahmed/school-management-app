function provjera(){
    var ime = document.getElementById("ime");
    var index = document.getElementById("index");
    var godina = document.getElementById("godina1")
    var poruka = document.getElementById("poruka");
    var validacija = new Validacija(poruka);
    var g =validacija.godina(godina);
    var i =validacija.ime(ime);
    var ins = validacija.index(index);
    if(g == true && i == true && ins == true) return true;
    return false;
    
}

function pregledaj(){
    var godina = document.getElementById("godina");
    var poruka = document.getElementById("poruka1");
    var validacija = new Validacija(poruka);
    if(!validacija.godina(godina)) return false;
    return true;    
}

var globLista = null;
function proslijedi(lista) {
    globLista = lista;
}

var nova = null;
function pozoviUcitaj() {
    if(nova == null) {
     nova = new BitBucket();
    nova.ucitaj("","",proslijedi);
   
    }
}


function pozovi() {
    var s = new StudentiAjax();
 s.pozovi(globLista);
}

function popuni() {
    var g = new PopunjavanjeAjax();
    g.dajGodine(); 
}