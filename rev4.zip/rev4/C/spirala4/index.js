

const db = require('./db.js');
//samo ako već nisu kreirani
db.sequelize.sync({force:true});



var express = require('express');
var app = express();
var path = require('path');
var url = require('url');
var fs = require('fs');
var csv = require('csv-writer').createObjectCsvWriter;
var bodyParser = require('body-parser');
var libxmljs = require('libxmljs');
var multer = require('multer');
var pug = require('pug');

app.listen(8080);

/*
Zadatak 1.
Prepravite zadatke 2,3,4,5 i 7 sa prošle spirale tako da koriste ovu bazu podataka.
*/

/*Zadatak 2*. 
Ukoliko se uputi zahtjev sa forme za unos zadatka sa poljima [name=naziv, type=text],
[name=postavka,type=file], opciju za odabir vježbe obrišite (neće vam trebati). Za enkodiranje podataka u
formi odaberite multipart/form-data . Za obradu multipart podataka možete koristiti multer paket. Nakon
što se ovakav POST zahtjev uputi na http://localhost:8080/addZadatak, server će odgovoriti sa novom
stranicom greska.html (gdje ćete ispisati navedenu poruku i omogućite korisniku da se vrati na raniju
formu) ukoliko tip fajla nije pdf ili ako zadatak sa istim imenom već postoji. Ukoliko zadatak ne postoji
kreira se fajl nazivZad.json gdje je naziv naziv iz forme i naziv.pdf fajl sa postavkom. U json fajlu se treba
nalaziti {naziv:NAZIV,postavka:LINK_ZA_DOWNLOAD_POSTAVKE}.
 */

 //postavljanje multera
  app.use(express.static(__dirname+'\\stranice'));

var spasit = multer.diskStorage({
    destination : './PDF',
    filename: function(req, file, callback){
        var ime = req.body.naziv;
    callback(null, ime+'.pdf');
    }
   });


var upload = multer({
    storage: spasit,
    //provjera imena i pdfa
    fileFilter: function(req,file,cb) {
        var pdf = file.mimetype;
      
       db.zadatak.findOne({where:{naziv:req.body.naziv}}).then(
           project => {
            console.log("jel postoji");
               console.log(project);
               if(project != null) {
                
                    req.ferror = 'postoji vec';
                    return cb(null,false,req.ferror);
                
               }
           }
       ); 
       if(pdf != 'application/pdf') {
            req.ferror = 'nije pdf';
            return cb(null,false,req.ferror);
        }
        cb(null,true);
    }
    });


app.post('/addZadatak', upload.single('postavka'),  (req, res) => {  
   
            if(req.ferror) {
                res.contentType('text/html');
                if(req.ferror == 'nije pdf') {
                 var html =pug.renderFile('greska.pug', {
                        name: 'Odabrani fajl nije pdf'
                 });
                 app.set('view engine','pug');
                 res.send(html);
                }
                else {
                    var html =pug.renderFile('greska.pug', {
                        'name': 'Postoji pdf s istim imenom'
                 });
                 app.set('view engine','pug');
                 res.send(html);
                }
            }     
            //ako je sve ok spasi pdf i json s nazivom
            else{
            var naziv = req.body['naziv'];
            var json = {naziv: naziv ,postavka: 'http://localhost:8080/'+naziv+'.pdf'};

            //upisat u bazu
            db.zadatak.create(json);
            
            res.contentType('application/json');
            json = JSON.stringify(json);
            fs.writeFile(path.join(__dirname+'\\PDF\\'+naziv+'Zad.json'), json, (err) => {
                if(!err) 
                console.log('ok je');
            });
            
            res.send(json);
        }
       
});

//ucitavanje linkova iz jsona
app.use(express.static(__dirname+'\\PDF'));
app.get(/^([a-zA-Z]([0-9]|(\/|\\|-|"|'|!|\?|:|;|,)|[a-z])+(\d|[a-z])).pdf$/m, function(req,res){
    var link = req.url;
    var duz = link.length;
    link = link.substr(1,duz);
    console.log(link);
    res.writeHead(200, {'Content-Type' : 'application/pdf'});
    res.sendFile(path.join(__dirname+'\\PDF\\'+link),null,function(err){
        if (err) {
            console.log(err);
            res.status(err.status).end();
          }
          else {
            console.log('Poslano:', link);
            res.end();
          }
    });
});


/*Zadatak 3. 
Ako se uputi GET zahtjev na http://localhost:8080/zadatak sa url parametrom naziv kao rezultat vraća se
pdf fajl sa postavkom. Napravite testne zadatke sa nazivima Zadatak1, Zadatak2 i Zadatak3, a postavka tih
zadataka neka bude ovaj dokument. Za zadatke dodane kroz formu vratite odgovarajuću postavku.
 */
app.get('/zadatak', function(req,res){
      var link = req.url;
     link = link.replace('/zadatak?','');
     var par = new url.URLSearchParams(link);   
     res.contentType('application/pdf');  
     if(par.has('naziv')){  
     //omoguceno i sa naziv.pdf i samo naziv
     var put =null;
     db.zadatak.findOne({where:{naziv:par.get('naziv')}}).then( p => {
         console.log(p);
         if(p != null) {
            if(par.get('naziv').includes('.pdf')) {
                put = path.join(__dirname+'\\PDF\\'+par.get('naziv'));
                }
                else {
                   put = path.join(__dirname+'\\PDF\\'+par.get('naziv')+'.pdf');
                }
                res.sendFile(put,null,function(err){
                    if (err) {
                        console.log(err);
                       res.contentType('text/html');
                       var html =pug.renderFile('greska.pug', {
                              name: 'Uneseni pdf ne postoji'
                       });
                       app.set('view engine','pug');
                       res.send(html);
                      }
                      else {
                        console.log('Poslano:', link);
                        res.end();
                      }
                });
         }
         else {
            res.contentType('text/html');
            var html =pug.renderFile('greska.pug', {
                   name: 'Uneseni pdf ne postoji'
            });
            app.set('view engine','pug');
            res.send(html);
         }
     })
     
 }
 });

/*Zadatak 4.
Ako se uputi POST zahtjev iz forme za unos godine sa poljima [name=nazivGod,type=text],
[name=nazivRepVje,type=text] i [name=nazivRepSpi,type=text] na url http://localhost:8080/addGodina u
fajl godine.csv na serveru se treba dodati novi red sa navedenim podacima. Ukoliko godina sa nazivGod
već postoji korisniku vratite greska.html, a ukoliko ne postoji vratite addGodina.html. */
global.pronadjiGodinu = function(ime) {    //POBRISAT!!! vracena<vrijednost i rezultat se ne koriste!!!!!!!!!!!!!!!!
    var data = fs.readFileSync('godine.csv');  
    let nizPodaci = data.toString('utf8').split('\n'); 
    const pronadji = ime;
    let nadjeno = -1; 
   
    for (let index=0; index<nizPodaci.length; index++) {
        var rijec = nizPodaci[index].split(',');
        if (rijec[0] == pronadji) {  
            nadjeno = index;       
        }
    }
  
   return nadjeno;
};

const csvWr = csv({
  path: 'godine.csv',
  header: [
      {id: 'godina', title: 'Naziv godine'},
      {id: 'vjezbe', title: 'Naziv repozitorija za vjezbe'},
      {id: 'spirala', title: 'Naziv repozitorija za spirale'}
  ],
  encoding: 'utf-8',
  append: true
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.post('/addGodina', function(req,res){
var podaci = req.body;
db.godina.findOne({where:{nazivGod:podaci['nazivGod']}}).then(rezultat => {
    if(rezultat != null) {
        res.contentType('text/html');
        var html =pug.renderFile('greska.pug', {
               name: 'Unesena godina vec postoji'
        });
        app.set('view engine','pug');
        res.send(html);
  
  }
  else {
      db.godina.create({nazivGod:podaci['nazivGod'],nazivRepSpi:podaci['nazivRepSpi'],nazivRepVje:podaci['nazivRepVje']});
    let podatak = [
        {godina: podaci['nazivGod'],  vjezbe: podaci['nazivRepVje'], spirala : podaci['nazivRepSpi']}
    ];
    csvWr.writeRecords(podatak)
    .then(() => {
        res.set('Content-Type', 'text/html; charset=utf-8');
        res.sendFile(path.join(__dirname+'\\stranice\\'+'addGodina.html'));
        //res.end(); trebal? 
    });
  }
});

});

/*Zadatak 5. 
Ako se uputi GET zahtjev na http://localhost:8080/godine vraća se JSON niz svih dodanih godina u
formatu [{nazivGod: ### ,nazivRepVje: ###, nazivRepSpi: ### }, ...]
 */
app.get('/godine',function(req,res) {
 
     db.godina.findAll({where:{}}).then(nizJSON => {        
        var niz = [];
        for(var el in nizJSON) {
           
            var json = {'nazivGod' : nizJSON[el].nazivGod, 'nazivRepVje' : nizJSON[el].nazivRepVje, 'nazivRepSpi': nizJSON[el].nazivRepSpi};
            niz.push(json);
           }
           res.writeHead(200, {'Content-Type' : 'application/json'});
        res.write(JSON.stringify(niz));  
        res.end();
     });
     
 });


 /* Zadatak 7.
Ukoliko se uputi GET zahtjev na http://localhost:8080/zadaci vraća se spisak svih zadataka u formatu json,
xml ili csv u zavisnosti koji je traženi format u headeru Accept. Ukoliko se više formata nalaze u navedenom
headeru vratite odgovor u jednom gdje je prioritet u sljedećem redosljedu json,xml pa csv. Npr. ako se traže
formati csv,xml vi vratite xml, ako se traze json,xml,csv vratite json i sl.
 */
app.get('/zadaci', function(req,res){
    var nizFajlova = [];
    var heder = req.headers.accept;    
    heder = heder.split(' ').join('');
    var nizHedera = heder.split(','); 
    console.log(nizHedera);   
 
    db.zadatak.findAll({where:{}}).then( nizFajlova => {
        console.log(JSON.stringify(nizFajlova));
   
    
    if(nizHedera.includes('application/json') || nizHedera.includes('*/*')) {
    //json format
       var jsonNiz = [];
       for(var el in nizFajlova) {
           var json = { naziv : nizFajlova[el].naziv, postavka : nizFajlova[el].postavka};
        jsonNiz.push(json);
       }
       res.contentType('application/json');
       res.send(JSON.stringify(jsonNiz));
   }
   else if(nizHedera.includes('application/xml') || nizHedera.includes('text/xml')) {
   //xml format
   var xml =  '<?xml version="1.0" encoding="UTF-8"?>';
                xml += '<zadaci>';
              for(var el in nizFajlova) {
               xml += '<zadatak>';
               xml += '<naziv> '+nizFajlova[el].naziv+' </naziv>';
               xml += '<postavka> '+nizFajlova[el].postavka+' </postavka>';
               xml += '</zadatak>';
              }
              xml += '</zadaci>';

       
       var xmlDoc = libxmljs.parseXml(xml);
       console.log(xmlDoc.toString());
       res.contentType('application/xml');
       res.send(xmlDoc.toString());
   } 
   else if(nizHedera.includes('text/csv')) {
    //csv format
   const csvWr = csv({
       path: 'pomocna.csv',
       header: [
           {id: 'naziv', title: 'Naziv pdfa'},
           {id: 'postavka', title: 'Pdf'},
       ],
       encoding: 'utf-8',
       append: true
   });
   //obrise sadrzaj fajla
   fs.truncate(path.join(__dirname+'\\pomocna.csv'), 0, function(){console.log('Izbrisano')});
   
   for(var el in nizFajlova) {
       var naziv = nizFajlova[el].naziv;
       console.log(naziv);
       var pdf = nizFajlova[el].postavka;
       let podatak = [
           { naziv: naziv,  postavka: pdf }
       ];
       res.contentType('text/csv');
       csvWr.writeRecords(podatak).then(() => {
         if(el == nizFajlova.length-1) {
           res.sendFile(path.join(__dirname+'\\pomocna.csv'));
       }
       });
      
       

       }
       if(nizFajlova.length == 0) res.end();
   }
   else {
       //ako nije nista od navedenog
       var jsonNiz = [];
       for(var el in nizFajlova) {
           var e = nizFajlova[el];
           console.log("hej "+e);
        var naziv = e['naziv'];
           var pdf = e['postavka'];
           var json = { naziv : naziv, postavka : pdf};
        jsonNiz.push(json);
       }
       res.contentType('application/json');
       res.send(JSON.stringify(jsonNiz));
   }
});
    });


//dodatani get zahtjev za vjezbe
app.get('/vjezbe',function(req,res) {
    db.vjezba.findAll().then( lista => {
        res.send(JSON.stringify(lista));
    })
})


/*
Zadatak 2.a 
Implementirajte funkcionalnost dodavanja vježbe/spirale. Ako se pošalje POST
zahtjev iz forme fPostojeca sa podacima sGodine i sVjezbe na url http://localhost:8080/addVjezba
kreira se veza između godine sa id-em sGodine i vježbom sa id-em sVjezbe. Nakon dodavanja
vratite na stranicu addVjezba.html
*/
/*db.vjezba.create({naziv:"Vjezba1" , spirala:false});
db.vjezba.create({naziv:"Vjezba2" , spirala:true});
db.vjezba.create({naziv:"Vjezba3" , spirala:true});
db.vjezba.create({naziv:"Vjezba4" , spirala:false});*/
/*
Zadatak 2.b 
Implementirajte funkcionalnost dodavanja nove vježbe/spirale. Ako se pošalje
POST zahtjev iz forme fNova sa podacima sGodine, naziv i spirala kreira se nova vježba sa
podacima naziv i postavlja joj se polje spirala na true ili false u zavisnosti od vrijednosti spirala iz
forme. Nakon kreiranja nove vježbe ona se povezuje sa godinom sa id-em sGodine. (Dodavanje
zadataka na vježbu ne radite u ovom zadatku) Nakon dodavanja vratite na stranicu addVjezba.html

*/

//provjerit imal medjuveza vec


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/addVjezba', function(req,res) {
var info = req.body;
var naziv = info['naziv'];
console.log(naziv);

if(naziv == "") {
    console.log("prva");
 db.godina.findOne({where:{nazivGod:info['sGodine']}}).then(god =>{
     db.vjezba.findOne({where:{naziv:info['sVjezbe']}}).then( vjezbe => {
         god.addVjezbe(vjezbe).then( function(){
             return new Promise( function(resolve, reject){
                 resolve(vjezbe);
                 
             });
         });
     });
 });
}
else {
    var sp = Boolean(info['spirala']);
    db.vjezba.findOrCreate({naziv:naziv,spirala:sp}).then( l => {  
  
        db.godina.findOne({where:{nazivGod:info['sGodine']}}).then( god => {
            db.vjezba.findOne({where:{naziv:naziv}}).then( vje=> {
            console.log(vje+" - - "+god);
            god.addVjezbe(vje).then( function() {
                return new Promise(function(resolve,reject){
                    resolve(vje);
                });
            });
        });
    });
});
}

 res.set('Content-Type', 'text/html; charset=utf-8');

 res.send(path.join(__dirname+'\\stranice\\'+'addVjezba.html'));



});

/*
Zadatak 2.c 
Dio iz forme fNova koji se odnosi na dodavanja zadataka na vježbu izdvojite u
novu formu (na istoj stranici). U novoj formi fPoveziZadatak treba da se nalazi
● select - name: sVjezbe
● select - name: sZadatak
● input submit - name: dZadatak
Kada se klikne na dugme dZadatak zadatak se dodaje na vježbu. Šalje se POST zahtjev na url
http://localhost:8080/vjezba/:idVjezbe/zadatak . U select tagu sZadatak prikažite sve zadatke koji već
nisu dodjeljeni odabranoj vježbi iz sVjezbe. Ne treba biti moguće u formi odabrati zadatak koji je već
dodan vježbi. Nakon dodavanja zadatka vratite na stranicu addVjezba.html
*/


// /vjezba?ime=
app.get('/vjezba', function(req,res) {
    var link = req.url;
    console.log(link);
    link = link.replace('/vjezba?','');
    var par = new url.URLSearchParams(link);
    var naziv = par.get('ime');
    console.log('ime '+naziv)
    
    db.zadatak.findAll().then(function(listaZadataka) {
    db.vjezba.findOne({where:{naziv:naziv}}).then(function(vje){
   
    vje.getZadaci().then(function(lista){
        var rez= [];
        listaZadataka.forEach( zad => {
            var br = 0;
        lista.forEach( vje_zad => {
          
          if(zad.id != vje_zad.id) br++;           
        });
      
        if(br == lista.length) rez.push({naziv:zad.naziv});
    });
    
      res.send(JSON.stringify(rez));
    })

})
})






});


app.post('/vjezba/:idVjezbe/zadatak', function(req,res) {

var idVjezbe = req.url.replace('/vjezba/:','');
idVjezbe = idVjezbe.replace('/zadatak','');
console.log(req.url);

//vjezba id, svi zadaci koji nisu vezani u medju tabeli
db.vjezba.findOne({where:{naziv:idVjezbe}}).then(function(vje){
    db.zadatak.findOne({where:{naziv:req.body.sZadatak}}).then(function(zad) {
        zad.addVjezbe(vje).then( function() {
            return new Promise(function(resolve,reject){
                resolve(vje);
            });
          
    })
})
})

res.redirect('http://localhost:8080/addVjezba.html');
res.end();




});

//ajax za 2c se nalazi u folderu stranice fajl PopunjavanjeAjax

/*
Zadatak 3.a 
Stranicu addStudent ispravite tako da ima jednu formu sa poljima
● select - name: sGodina
● input text - name: key
● input text - name: secret
● button - value: Učitaj
● input button- value: Dodaj, disabled
- Kada se klikne na dugme učitaj kreira se instanca modula BitBucket (ako već nije kreirana) i
poziva se metoda modula BitBucket.ucitaj(nazivRepSpi,nazivRepVje,callback)
- Nakon učitavanja liste studenata omogućen je klik na dugme dodaj
- Klikom na dugme dodaj pravi se POST zahtjev putem AJAX-a na
http://localhost:8080/student i šalju se podaci u JSON formatu
{godina:X,studenti:[{imePrezime: Y, index: Z},...]}. Na serveru ukoliko ne postoji student sa
imenom i indexom dodaje se i onda se upisuje na godinu koja ima id X. Ako student već
postoji tada se samo upisuje (student postoji ukoliko već postoji neki student sa istim
indexom u bazi). Nakon obrađenog zahtjeva vratite JSON kao odgovor {message:”Dodano
je N novih studenata i upisano M na godinu NAZIVGODINE”}. Tekst poruke ispišite u web
browseru kao alert. Broj N predstavlja broj studenata koji nisu postojali u sistemu i koji su
dodani, M predstavlja ukupan broj studenata koji su upisani na godinu.
*/
'use strict';

app.post('/student', async function (req, res) {

console.log(req.body);
var jsonObj = req.body;
var listaStudenata = jsonObj.studenti;

var n = 0;
var m = 0;


let id = await db.godina.findOne({where:{nazivGod:jsonObj.godina}});

    for(var i = 0; i < listaStudenata.length; i++) {
     var studente = listaStudenata[i];
    console.log(studente);
let st = await db.student.findOne({where:{index:studente.index}});
    
    if(st == null) {
        console.log("uslo");
        
            if(id != null) {
            var json = {imePrezime:studente.imePrezime,index:studente.index,studentGod:id.id};
            await db.student.create(json);
            n++;
            }         
       
   
    }
    else if(st != null) {
        if(id != null)  {
            id.addStudenti(st);
            m++;
        }                    
       

    }
}
/*
let m = await db.student.findAndCountAll({where:{studentGod:id.id}});
m = m.count;*/
m += n;
return res.status(200).send({message:'Dodano je '+n+' novih studenata i upisano '+m+' na godinu '+jsonObj.godina});




});


