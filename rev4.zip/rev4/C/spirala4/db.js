/**
 *  ime wt2018,username i password  root,
 *  baza neka se nalazi na standarnom portu
 */
const Sequelize = require("sequelize");
//treba localhost stavit ,operatorsAliases:false
const sequelize = new Sequelize("wt2018","root","root",{host:"localhost",dialect:"mysql"});
const db = {};

db.Sequelize = Sequelize;
db.sequelize =sequelize;

//import modela
db.student = sequelize.import(__dirname+'/student.js');
db.godina = sequelize.import(__dirname+'/godina.js');
db.zadatak = sequelize.import(__dirname+'/zadatak.js');
db.vjezba = sequelize.import(__dirname+'/vjezba.js');

//veze
//godina sadrzi vise studenta
db.godina.hasMany(db.student,{foreignKey:"studentGod",as:"studenti"});
//godina moze imate vise vjezbi, a vjezba moze biti na vise godina
db.godineVjezbe = db.vjezba.belongsToMany(db.godina,{foreignKey:"idvjezba",as:"godine",through:"godina_vjezba"});
db.godina.belongsToMany(db.vjezba,{foreignKey:"idgodina",as:"vjezbe",through:"godina_vjezba"});
//vjezba moze da ima vise zadataka, a zadatak se moze nalaziti u vise vjezbi
db.zadaciVjezbi = db.vjezba.belongsToMany(db.zadatak,{foreignKey:"idvjezba",as:"zadaci",through:"vjezba_zadatak"});
db.zadatak.belongsToMany(db.vjezba,{foreignKey:"idzadatak",as:"vjezbe",through:"vjezba_zadatak"});

module.exports=db;

