var BitBucket = (function(){
    var konstruktor = function(key, secret){
        var ajax = new XMLHttpRequest();
        
        ajax.onreadystatechange = function () { // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
                new Promise(function(resolve,reject){
                   resolve(JSON.parse(ajax.responseText).access_token);
                
                });
                }
                var uspjeh = function(x){
                    console.log(x);
                }
                var neuspjeh = function(poruka){
                    console.log("Došlo je do greške: "+poruka);
                }
                
            
            if ( ajax . readyState == 4 && ajax . status == 404 )
                fnCallback(ajax.status,null);
        }
        ajax.open ( "POST", "https://bitbucket.org/site/oauth2/access_token", truee ) ;
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        return {
            ucitaj: function(nazivRepSpi, nazivRepVje, fnCallback)
            {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                    {
                console.log(ajax.responseText);
                console.log(JSON.parse(ajax.responseText).values[0].name);
                console.log(JSON.parse(ajax.responseText).values[0].owner.username);
               //Dodajte dio koji će u HTML ispisati tabelu sa repozitorijima
                 var podaci = JSON.parse(ajax.responseText);
                 var repozitoriji=[];
                 var imena=[];
                 for(var i=0; i<podaci.values.length; i++) {
                
                        imena.push(podaci.values[i].owner.username);
                     
                 }
               //Imena repozitorija možete dobiti sa podaci.values[i].name
               //Imena vlasnika repozitorija sa podaci.values[i].owner.username
           }
            else if (ajax.readyState == 4)
            console.log(ajax.status);
            }
            ajax.open("GET",'https://api.bitbucket.org/2.0/repositories/?role=member&q=name~nazivRepSpi,nazivRepVje',false);
                ajax.setRequestHeader("Authorization", 'Bearer ' + token);
                ajax.send();

            }
        }

    }
    return konstruktor;
}());