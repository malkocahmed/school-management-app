const express = require ( 'express' );
const fs = require ( 'fs' );
const multer = require ( 'multer' );
const bodyParser = require ( "body-parser" );
var builder = require('xmlbuilder');
const Sequelize = require('sequelize');
const db = require('./db.js');

db.sequelize.sync();


const app = express();
const upload = multer({ dest: 'client/' });
//zadatak 1
app.use(bodyParser());
app.use(express.static( __dirname + '/client' ));

app.post('/student', function(req,res){

    console.log(req.body);
});

app.post('/addVjezba',function(req,res){
if(req.body.vjezba==null) {
    var godina = req.body.sGodine;
    var vjezba= req.body.sVjezbe;
    var naslo=false;

    db.godina.findOne({ where : {nazivGod:godina} }).then(function(rezultat){
        if(rezultat!=null) {
            var id_godine= rezultat["id"];
            db.vjezba.findOne({ where : {naziv:vjezba} }).then(function(rezultat1){
                if(rezultat1!=null) {
                    var id_vjezbe= rezultat["id"];
                    rezultat.getVjezbe().then(function(rezultat3) {
                        if(rezultat3!=null) {
                            rezultat3.forEaforEach(element => {
                                if(element["id"]==id_vjezbe) {
                                naslo=true;
                                
                                }
                            });
                            if(naslo==false) {
                                rezultat.addVjezbe(id_vjezbe).then(function(rezultat4){
                                    
                                })
                            }
                            
                        }
                    })
                
                }
                    
                
            }) 
        }
            
    }) 
    res.redirect('/addVjezba.html');
        
}
else {
    var godina = req.body.sGodine;

    db.vjezba.findOne({ where : {naziv:req.body.vjezba} }).then(function(rezultatodg){
        if(rezultatodg==null) {
           
   

    if(req.body.spirala!=null) {

    db.vjezba.create({naziv:req.body.vjezba, spirala:true }).then(function(rezultat){
        console.log("uslo");
        db.godina.findOne({ where : {nazivGod:godina} }).then(function(rezultat2){
            if(rezultat2!=null) {
                var id_godine= rezultat2["id"];
                rezultat2.addVjezbe(rezultat["id"]);
            }
        });
        
    }).catch(function(err) {
        // print the error details
        res.end();
    });
 
    }
    else {
        db.vjezba.create({naziv:req.body.vjezba, spirala:false }).then(function(rezultat){
            db.godina.findOne({ where : {nazivGod:godina} }).then(function(rezultat2){
                if(rezultat2!=null) {
                    var id_godine= rezultat2["id"];
                    rezultat2.addVjezbe(rezultat["id"]);
                }
            });
        
        }).catch(function(err) {
            // print the error details
            res.end();
        });
        
    }
  
}

});

}
res.redirect('/addVjezba.html');
});
app.get ( '/addGodina.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/addGodina.html");
   
});
app.get ( '/login.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/login.html");
   
});
app.get ( '/addStudent.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/addStudent.html");
   
});
app.get ( '/addVjezba.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/addVjezba.html");
   
});
app.get ( '/addZadatak.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/addZadatak.html");
   
});
app.get ( '/zadaci.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/zadaci.html");
   
});
app.get ( '/studenti.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/studenti.html");
   
});
app.get ( '/commiti.html' , function ( req , res ){
    res.sendFile(__dirname + '/client' + "/studenti.html");
   
});
//zadatak 3
app.get ( '/zadatak' , function ( req , res ){
    db.zadatak.findOne({ where : {naziv:req.query.naziv} }).then(function(rezultat){
        if(rezultat!=null) {
            res.sendFile(__dirname + '/' + req.query.naziv +'.pdf');
            }
            
        else{
            res.redirect('/greska.html');
        }
    }) 


  /*  if (fs.existsSync(__dirname + '/' + req.query.naziv +'.pdf')) {
    res.sendFile(__dirname + '/' + req.query.naziv +'.pdf');
    }
    else {
        res.redirect('/greska.html');
    }*/
   
});
// zadatak 5 - provjeriti validnost
app.get ( '/godine' , function ( req , res ){
    var array=[];
    db.godina.findAll().then(function(rezultat){
        if(rezultat!=null) {
            for(var i=0; i<rezultat.length; i++) {
            var object={id:rezultat[i]["id"],nazivGod:rezultat[i]["nazivGod"], nazivRepVje:rezultat[i]["nazivRepVje"],nazivRepSpi:rezultat[i]["nazivRepSpi"]};
            array.push(object);
          
            }
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(array));
            
        }
        else{
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(array));
        }
    }) 

    /*fs.readFile('godine.csv', function(err, contents) {
        var lines=contents.toString().split("\n");
        var array=[];
        for(var i=0; i<lines.length; i++) {
            var columns=lines[i].split(",");
            var object={nazivGod:columns[0], nazivRepVje:columns[1],nazivRepSpi:columns[2]};
            array.push(object);
        }
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify(array));
    });*/
   
});

app.get ( '/vjezbe' , function ( req , res ){
    var array=[];
    db.vjezba.findAll().then(function(rezultat){
        if(rezultat!=null) {
            for(var i=0; i<rezultat.length; i++) {
            var object={id:rezultat[i]["id"],naziv:rezultat[i]["naziv"], spirala:rezultat[i]["spirala"]};
            array.push(object);
          
            }
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(array));
            
        }
        else{
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(array));
        }
    }) 
});
// zadatak 4
app.post ( '/addGodina' , function ( req , res ){
    
    db.godina.findOne({ where : {nazivGod:req.body.nazivGod} }).then(function(rezultat){
        if(rezultat==null) {
            db.godina.create({nazivGod:req.body.nazivGod, nazivRepVje:req.body.nazivRepVje,nazivRepSpi:req.body.nazivRepSpi }).then(function(rezultat){
                res.redirect('/addGodina.html');
            });
            
        }
        else{
            res.redirect('/greska.html');
        }
    }) 

  
    
    

    /*var niz=[];
    var array = [req.body.nazivGod, req.body.nazivRepVje, req.body.nazivRepSpi];
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent=array + "\r";

    fs.readFile('godine.csv', function(err, contents) {
        var lines=contents.toString().split("\n");
        var godina =req.body.nazivGod;
        
        for(var i=0; i<lines.length; i++) {
            var columns=lines[i].split(",");
            
            niz.push(columns[0]);
    
        }
        if(niz.includes("")== true) {
            csvContent=csvContent;
           
        }
        else {
            csvContent="\n" + csvContent;
        }
        if(niz.includes(godina)==true) {
            res.redirect('/greska.html');
        }
        
        else {
    
            fs.appendFile('godine.csv', csvContent, function (err) {
    
                if (err) throw err;
                console.log('Saved!');
                res.redirect('/addGodina.html');
       
            });
        }
        
    });
   */
});

app.get ( '/spirale/:id' , function ( req , res ){
    var array =[];
    var idVjezbe=req.params.id;
    console.log(idVjezbe);
    console.log("uslo");
    db.zadatak.findAll().then(function(rezultat){
        if(rezultat!=null) {
        db.vjezba.findOne({where:{id:idVjezbe}}).then(function(rezultat1){
            //dodati provjere ako je null
            rezultat1.getZadaci().then(function(rezultat2){
            
            rezultat.forEach(element => {
                if (!rezultat2.find(x => x.dataValues.id == element["id"])) {
                    array.push({id:element["id"],naziv:element["naziv"]});
                } 
            });
            
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(array)); 
                });
            });
        
        }


    }) ;

});
app.get ( '/zadaci' , function ( req , res ){
    
    if(req.accepts('application/json')) {
        var array=[];
        db.zadatak.findAll().then(function(rezultat){
            if(rezultat!=null) {
                for(var i=0; i<rezultat.length; i++) {
                var object={naziv:rezultat[i]["naziv"], postavka:rezultat[i]["postavka"]};
                array.push(object);
              
                }
                res.writeHead(200, {'Content-Type': 'application/json'});
                res.end(JSON.stringify(array));
                
            }
            else{
                res.writeHead(200, {'Content-Type': 'application/json'});
                res.end(JSON.stringify(array));
            }
        }) 
    }
    else if(req.accepts('application/xml')) {
      
            var root = builder.create('zadaci',  { encoding: 'UTF-8' });

            db.zadatak.findAll().then(function(rezultat){
                if(rezultat.length!=0) {
                    for(var i=0; i<rezultat.length; i++) {
                        //var columns=lines[i].split(" ");
                        console.log("uslo");
                        var item = root.ele('zadatak')
                        .ele('naziv', rezultat[i]["naziv"]).up()
                        .ele('postavka', rezultat[i]["postavka"]).up();
                   
                    }
                    res.writeHead(200, {'Content-Type': 'application/xml'});
                    res.end(root.end({ pretty: true }));
                }
                else {
                   
                    res.writeHead(200, {'Content-Type': 'application/xml'});
                    var string = "<?xml version="+"1.0"+ "encoding="+"UTF-8"+"?>" + "\n" +
                    "<zadaci>" + "\n" + "</zadaci>";
                    res.end(string);
                }
               
            }) 

          
            
            
        


    }
    else if(req.accepts('text/xml')) {
        var root = builder.create('zadaci',  { encoding: 'UTF-8' });

        db.zadatak.findAll().then(function(rezultat){
            console.log(rezultat.length);
            if(rezultat.length!=0) {
                console.log("uslo");
                for(var i=0; i<rezultat.length; i++) {
                    //var columns=lines[i].split(" ");
                    //console.log(columns);
                    var item = root.ele('zadatak')
                    .ele('naziv', rezultat[i]["naziv"]).up()
                    .ele('postavka', rezultat[i]["postavka"]).up();
               
                }
                res.writeHead(200, {'Content-Type': 'application/xml'});
                res.end(root.end({ pretty: true }));
            }
            else {
                console.log("uslo");
                res.writeHead(200, {'Content-Type': 'application/xml'});
                res.end(root);
            }
           
        }) 

      
        
       
    }
    else if(req.accepts('text/csv')) {

        let csvContent="";

            db.zadatak.findAll().then(function(rezultat){
                if(rezultat!=null) {
                    for(var i=0; i<rezultat.length; i++) {
                        csvContent+=rezultat[i]["naziv"]+','+ rezultat[i]["postavka"] + "\r\n";
                   
                    }
                    res.writeHead(200, {'Content-Type': 'text/csv'});
                    res.end(csvContent);
                }
                else {
                    res.writeHead(200, {'Content-Type': 'text/csv'});
                    res.end(csvContent);
                }
               
            }) 

          
            
        
      
        /*fs.readFile('zadaci.txt', function(err, contents) {
            var lines=contents.toString().split("\n");
            var array;
            for(var i=0; i<lines.length; i++) {
                var columns=lines[i].split(" ");
                console.log(columns);
                csvContent+=columns[0] +','+ columns[1] + "\r\n";
            }*/
     
        

    }
   
});
app.post ('/vjezba/:idVjezbe/zadatak', function ( req , res ){
    db.vjezba.findOne({where:{id:req.body.sVjezbe}}).then(function(rezultat){
        if(rezultat!=null) {
        rezultat.addZadaci(req.body.sZadatak);
        }

    });
//redirect moram uradiitii

    res.redirect("/addVjezba.html");
});
//zadatak 2
app.post ( '/addZadatak', function ( req , res ){
   
    var ekstenzija;
    var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        ekstenzija = file.mimetype;
      cb(null, __dirname)
    },
    filename: (req, file, cb) => {
      cb(null, req.body.naziv + '.pdf')
    }
   
    });
    var upload = multer({storage: storage,
        fileFilter: function (req, file, callback) {
            if (file.mimetype != 'application/pdf') {
                
                return callback(new Error('Only pdfs are allowed'))
            }
            
            if (fs.existsSync(__dirname + '/' + req.body.naziv + ".pdf")) {
                return callback(new Error('Postoji s ovim imenom'))
            }
            var zadaci={"naziv": req.body.naziv,
            "postavka": "http://localhost:8080/zadatak?naziv=" +  req.body.naziv};
            var string = JSON.stringify(zadaci);
            db.zadatak.findOne({ where : {naziv:req.body.naziv} }).then(function(rezultat){
                if(rezultat==null) {
                    db.zadatak.create({naziv:req.body.naziv, postavka:"http://localhost:8080/zadatak?naziv=" +  req.body.naziv }).then(function(rezultat){
                      
                    });
                    
                }
                else{
                    res.redirect('/greska.html');
                }
            }) 
            fs.writeFile( req.body.naziv +"Zad.json", string,function (err) {
                console.log(req.body.naziv +"Zad.json");
                if (err) throw err;
            });
            callback(null, true)
        },}).single('postavka');

    upload(req, res, function (err) {
        if (err) {
            res.redirect("/greska.html");
            
        }
      
       res.end();
    })
});

app.listen (8080);