function spinnerVjezba() {
    var ajax = new XMLHttpRequest();
            
            ajax.onreadystatechange = function () { // Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200 ) {
                if(ajax.responseText) {
                var object = JSON.parse(ajax.responseText);
                    console.log(object);
                var d = document.getElementsByName('sVjezbe');
                object.forEach(element => {
                    
                    var option = document.createElement("option");
                    option.value = element.id;
                    option.text = element.naziv;
                   
                    
                    d[0].add(option);
                    var option1 = document.createElement("option");
                    option1.value = element.id;
                    option1.text = element.naziv;
                   
                    d[1].add(option1);
                    
                    
                });
                }
                
                }
                
                if ( ajax . readyState == 4 && ajax . status == 404 )
                console.log("greska");
            }
            ajax.open ( "GET" , "http://localhost:8080/vjezbe" , true ) ;
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send();
    }

 /*   var e = document.getElementByName("sVjezbe")[1];
e.onchange = function(){funkcija()};

function funkcija() {
    var strUser = e.options[e.selectedIndex].value;
}*/