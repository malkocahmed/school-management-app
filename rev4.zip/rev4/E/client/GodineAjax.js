var GodineAjax = (function(){
    var konstruktor = function(divSadrzaj){
        var ajax = new XMLHttpRequest();
        
        ajax.onreadystatechange = function () { // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200 ) {
            if(ajax.responseText) {
            var object = JSON.parse(ajax.responseText);

           
            object.forEach(element => {
                var d = document.createElement('div');
                d.setAttribute("class", "godina");
                d.innerHTML=" <p>" + element.nazivGod + "</p> <br> <p>" + element.nazivRepVje + "</p> <br> <p>" + element.nazivRepSpi + "</p>";
                divSadrzaj.appendChild(d);
                
            });
            }
            
            }
            
            if ( ajax . readyState == 4 && ajax . status == 404 )
            console.log("greska");
        }
        ajax.open ( "GET" , "http://localhost:8080/godine" , true ) ;
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        return {
        osvjezi:function(){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function () { // Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200 ) {
                    divSadrzaj=ajax.responseText;
                }
                
                if ( ajax . readyState == 4 && ajax . status == 404 )
                console.log("greska");
            }
            ajax.open ( "GET" , "http://localhost:8080/godine" , true ) ;
            ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
        }
        }
    }
    return konstruktor;
}());