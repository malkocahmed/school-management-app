var BitBucket = (function(){
    
    var konstruktor = function(key, secret){
        
        var token = new Promise(
            function (resolve, reject) {
               
                      
             
        
            
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function () { // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200) {
              
                       resolve(JSON.parse(ajax.responseText).access_token);
                       
                        
                       reject(
                        "Greska"
                       )
                         
              
            }
                
            
            if ( ajax . readyState == 4 && ajax . status == 404 ) {
                reject(
                    "Greska"
                   )
                console.log("Ne valja");
            }
        }
        

        ajax.open ( "POST", "https://bitbucket.org/site/oauth2/access_token", true ) ;
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+':'+secret));
        console.log(key +","+ secret);
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
    }
        );
        return {
            ucitaj: function(nazivRepSpi, nazivRepVje, fnCallback)
            {
                var neuspjeh = function(poruka){
                    fnCallback("Greska, token nije ispravan", null);
                }
                
                
               
                token.then(function(mojtoken, neuspjeh) {
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                    if (ajax.readyState == 4 && ajax.status == 200){
                       

                    var podaci = JSON.parse(ajax.responseText);
            
                    var repozitoriji=[];
                    var imena=[];
                    var indeksi=[];
                    var array=[];
                    for(var i=0; i<podaci.values.length; i++) {
                       
                        
                        if(podaci.values[i].name.startsWith(nazivRepSpi) || podaci.values[i].name.startsWith(nazivRepVje)){
                            var ime = podaci.values[i].owner.username;
                            
                            var index = podaci.values[i].name.substr(podaci.values[i].name.length - 5);
                            if(imena.includes(ime)==false) {
                            var object={imePrezime:ime, index:index};
                            array.push(object);
                            imena.push(ime);
                          
                            }
    
                        }
                    }
                  
                    
                    fnCallback(null, array);

                    }
                    else if (ajax.readyState == 4) {
                    console.log(ajax.status);
                    fnCallback("Greska, token nije ispravan", null);
                    }
                }
               
                ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&q=(name~\""+encodeURIComponent(nazivRepSpi)+"\" OR name~\""+encodeURIComponent(nazivRepVje)+"\")");
                ajax.setRequestHeader("Authorization", 'Bearer ' + mojtoken);
                ajax.send();

            });
            

            }
        
        
        }

    }
    return konstruktor;
}());


