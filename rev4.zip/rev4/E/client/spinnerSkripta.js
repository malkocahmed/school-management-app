
function spinner() {
var ajax = new XMLHttpRequest();
        
        ajax.onreadystatechange = function () { // Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200 ) {
            if(ajax.responseText) {
            var object = JSON.parse(ajax.responseText);
                console.log(object);
            var d = document.getElementsByName('sGodine');
            object.forEach(element => {
                
                var option = document.createElement("option");
                var option1 = document.createElement("option");
                option.text = element.nazivGod;
                option1.text = element.nazivGod;
                
                d[0].add(option);
                d[1].add(option1);
                
                
            });
            }
            
            }
            
            if ( ajax . readyState == 4 && ajax . status == 404 )
            console.log("greska");
        }
        ajax.open ( "GET" , "http://localhost:8080/godine" , true ) ;
        ajax.setRequestHeader("Content-Type", "application/json");
        ajax.send();
}