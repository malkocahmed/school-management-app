var lista;
function nadugmeUcitaj(){
    var key = document.getElementsByName("key")[0].value;
    var secret = document.getElementsByName("secret")[0].value;


   var bbucket = new BitBucket(encodeURIComponent(key),encodeURIComponent(secret));
   function ispisi(greska,x){
       if(greska==null) {
        document.getElementById("dugme").disabled = false;
           console.log("Lista studenata:\n"+JSON.stringify(x));
           lista=x;
       }
       }
       
   bbucket.ucitaj("wtv2018","wt18",ispisi);

}

function nadugmeDodaj() {

    var ajax = new XMLHttpRequest();

    var  god=document.getElementsByName("sGodina")[0];
    console.log(god);
    var selektovaniID = god.options[god.selectedIndex].value;
    console.log(selektovaniID);
    var objekat={godina:selektovaniID,studenti:lista};
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 

          //  var studneti = JSON.parse(ajax.responseText);
         

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
    ajax.open('POST', 'http://localhost:8080/student', true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(objekat));
}