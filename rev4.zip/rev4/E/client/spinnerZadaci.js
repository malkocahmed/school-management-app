function spinnerZadaci() {
    var ajax = new XMLHttpRequest();
    var  opcija=document.getElementsByName("sZadatak")[0];
    var  opcija1=document.getElementsByName("sZadatak")[1];
    var vjezba=document.getElementsByName("sVjezbe")[1];
    opcija.options.length=0;
    opcija1.options.length=0;
    var id = vjezba.options[vjezba.selectedIndex].value;
    ajax.onreadystatechange = function () { 
        if (ajax.readyState == 4 && ajax.status == 200 ) {
        if(ajax.responseText) {
           
     
           
            
            var array = JSON.parse(ajax.responseText);
         
        
            array.forEach(element => {
                var ubaci = document.createElement("option");
                var ubaci1 = document.createElement("option");
                ubaci.value=element.id;
                ubaci.text = element.naziv;   
               
                ubaci1.value = element.id;
                ubaci1.text = element.naziv;            
                opcija.add(ubaci);
                opcija1.add(ubaci1);
            
                
            });
        
        }
    }
        
        if ( ajax . readyState == 4 && ajax . status == 404 )
        console.log("greska");
    }
    ajax.open ( "GET" , "http://localhost:8080/spirale/"+id , true ) ;
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
}






function promijeniaction() {
    var frm = document.getElementById('fPoveziZadatak');
    vjezba=document.getElementsByName("sVjezbe")[1];
    var id = vjezba.options[vjezba.selectedIndex].value;
    if(frm) {
    frm.action = '/vjezba/' +id+'/zadatak' 
    }
}