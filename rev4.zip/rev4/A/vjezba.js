var Sequelize = require('sequelize');
var sequelize = require('./db');

var Vjezba = sequelize.define('Vjezba', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true
  },
  naziv: {
    type: Sequelize.STRING,
    unique: true,
  },
  spirala: Sequelize.STRING,
});

module.exports = Vjezba;