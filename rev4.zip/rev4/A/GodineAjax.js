var GodineAjax = (function() {
  var konstruktor = function(divSadrzaj) {
    function osvjezi() {
      function reqListener () {
        divSadrzaj.text = this.responseText;
      }

      var oReq = new XMLHttpRequest();
      oReq.addEventListener("load", reqListener);
      oReq.open("GET", "http://localhost:8080/godine");
      oReq.send();
    }

    osvjezi();

    return {
      osvjezi: osvjezi
    };
  }

  return konstruktor;
}());
module.exports = GodineAjax;