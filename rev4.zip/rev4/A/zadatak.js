var Sequelize = require('sequelize');
var sequelize = require('./db');

var Zadatak = sequelize.define('Zadatak', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true
  },
  naziv: Sequelize.STRING,,
  postavka: Sequelize.STRING,,
});

module.exports = Zadatak;