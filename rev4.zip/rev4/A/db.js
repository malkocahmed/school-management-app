var Sequelize = require('sequelize');
var sequelize = new Sequelize('postgres://user:pass@example.com:5432/dbname');
module.exports = sequelize;