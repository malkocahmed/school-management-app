var Sequelize = require('sequelize');
var sequelize = require('./db');

var Student = sequelize.define('Student', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true
  },
  imePrezime: Sequelize.STRING,
  index: {
    type: Sequelize.STRING,
    unique: true
  }
});

module.exports = Student;