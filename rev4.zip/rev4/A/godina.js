var Sequelize = require('sequelize');
var sequelize = require('./db');
var Student = require('./student');

var Godina = sequelize.define('Godina', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true
  },
  naziv: {
    type: Sequelize.STRING,
    unique: true
  },
  nazivRepSpi: Sequelize.STRING,
  nazivRepVje: Sequelize.STRING,
});

Godina.hasMany(Student, {
  foreignKey: 'studentGod',
  as: 'studenti'
});

module.exports = Godina;