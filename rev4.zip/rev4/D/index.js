const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
var json2csv = require('json2csv');
var builder = require('xmlbuilder');
var multer  = require('multer');
//var html=require('html')
const Sequelize = require('sequelize');
const db= require('./db.js');
//const sequelize = require('./baza.js');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


/*const student=sequelize.import(__dirname+'/student.js');
student.sync();

const godina=sequelize.import(__dirname+'/godina.js');
godina.sync();

const vjezba=sequelize.import(__dirname+'/vjezba.js');
vjezba.sync();

const zadatak=sequelize.import(__dirname+'/zadatak.js');
zadatak.sync();*/

db.sequelize.sync();



app.get('/zadatak', function(req, res) {
   

    var nazivfile = req.query.naziv;
  // var file = __dirname + '/zadaci/' + naziv+'.pdf';

   /* var path= './zadaci/' + naziv+'.pdf';

    if (fs.existsSync(path)) res.sendFile(file);
    else res.send('Taj zadatak ne postoji');*/
    
    db.zadatak.findOne({where:{naziv:nazivfile}}).then(function(odg) {
        if(odg==null) {res.send('Taj zadatak ne postoji'); }
        else {var file = __dirname + '/zadaci/' + odg["naziv"]+'.pdf';
        res.sendFile(file); }
    })
    

});

app.post('/addGodina', function(req, res) {
    var tijelo = req.body;
    var path='./godine.csv';
    var csv = json2csv.parse(tijelo);
    var csv2=csv.replace(/"/g,'');
    csv2=csv2.substr(34);
    var newLine= "\r\n";
    var postoji=false;
    
   /* if (!fs.existsSync(path)) {
    fs.appendFile('godine.csv', csv2, function (err) {
    
        if (err) throw err;
       res.redirect('/addGodina.html');
    }); }

   

    else { 
        
       fs.readFile('godine.csv', function(err,contents) {
           var postoji=false;
        var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n"); 
        var niz=[];
        for(var i=0; i<redovi.length; i++) {
        var kolona=redovi[i].split(",");
        var objekat={nazivGod:kolona[0] ,nazivRepVje:kolona[1], nazivRepSpi:kolona[2]};
        niz.push(objekat);
        if(niz[i].nazivGod==tijelo.nazivGod) { postoji=true; break;}
        }
    
          if(!postoji) {  fs.appendFile('godine.csv', newLine+csv2, function (err) {
                if (err) throw err;


                res.redirect('/addGodina.html');
        });
    }
    else res.redirect('/greska.html');
    
       });
    }*/

    
   
    var kolona=csv2.split(",");
    db.godina.findOne({where:{nazivGod:kolona[0]}}).then(function(odg) {
        if(odg==null){ db.godina.create({nazivGod: kolona[0], nazivRepSpi : kolona[1], nazivRepVje: kolona[2]}).then( function(odg) {
            console.log("upisano2");
            res.redirect('/addGodina.html');
         }) }
        else {postoji=true; console.log("postoji"); res.redirect('/greska.html');}
    });

 /*  if(postoji==false) { godina.create({nazivGod: kolona[0], nazivRepSpi : kolona[1], nazivRepVje: kolona[2]}).then( function(odg) {
       console.log("upisano2");
       res.redirect('/addGodina.html');
    })
}
  //  else res.redirect('/greska.html');*/

}); 

app.get('/godine', function(req, res) {
  /*  var path='./godine.csv';
    if (fs.existsSync(path)){
    fs.readFile('godine.csv', function(err, contents) {
      
        var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n"); 
        var niz=[];
        for(var i=0; i<redovi.length; i++) {
        var kolona=redovi[i].split(",");
        var objekat={nazivGod:kolona[0] ,nazivRepVje:kolona[1], nazivRepSpi:kolona[2]};
        niz.push(objekat);
    }

res.writeHead(200, {'Content-Type': '/application/json'});
res.end(JSON.stringify(niz));
    }); }*/

    db.godina.findAll().then(function(odgovor) {
        if(odgovor==null) {
            var niz=[]; 
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(niz));
        }
       else{ var niz=[];
        for(var i=0; i<odgovor.length; i++) {
        var objekat={id:odgovor[i]["id"],nazivGod:odgovor[i]["nazivGod"] ,nazivRepSpi:odgovor[i]["nazivRepSpi"],nazivRepVje:odgovor[i]["nazivRepVje"]};
        niz.push(objekat);
        }
        res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(niz));
    }
    });
   
});

app.get('/popunizadatke', function(req, res) {
    
  
      db.zadatak.findAll().then(function(odgovor) {
          if(odgovor==null) {
              var niz=[]; 
              res.writeHead(200, {'Content-Type': '/application/json'});
              res.end(JSON.stringify(niz));
          }
         else{ var niz=[];
          for(var i=0; i<odgovor.length; i++) {
          var objekat={naziv:odgovor[i]["naziv"] ,postavka:odgovor[i]["postavka"]};
          niz.push(objekat);
          }
          res.writeHead(200, {'Content-Type': '/application/json'});
          res.end(JSON.stringify(niz));
      }
      });
     
  });

  app.get('/popunizadatke2/:id', function(req, res) {
    
    
    var idOdabraneVjezbe=req.params.id;
   // console.log(idOdabraneVjezbe)
    db.vjezba.findOne({where:{id:idOdabraneVjezbe}}).then(function(odgovor) {
        if(odgovor!=null) {
            odgovor.getZadaci().then(function(odgovor2) {
                if(odgovor2.length!=0) {
                    
               
                    
                    db.zadatak.findAll().then(function(odgovor3) {
                        var niz=[];
                        for(var j=0; j<odgovor3.length;j++) {
                            if(!odgovor2.find(x=>x.dataValues.id==odgovor3[j]["id"])) {
                                var objekat={id:odgovor3[j]["id"],naziv:odgovor3[j]["naziv"] ,postavka:odgovor3[j]["postavka"]};
                                niz.push(objekat);
                               
                            }
                        }
                        res.writeHead(200, {'Content-Type': '/application/json'});
                        res.end(JSON.stringify(niz));
                    })
                
            }
            else {
                db.zadatak.findAll().then(function(odgovor) {
                    if(odgovor==null) {
                        var niz=[]; 
                        res.writeHead(200, {'Content-Type': '/application/json'});
                        res.end(JSON.stringify(niz));
                    }
                   else{ var niz=[];
                    for(var i=0; i<odgovor.length; i++) {
                    var objekat={id:odgovor[i]["id"],naziv:odgovor[i]["naziv"] ,postavka:odgovor[i]["postavka"]};
                    niz.push(objekat);
                   
                    }
                    res.writeHead(200, {'Content-Type': '/application/json'});
                    res.end(JSON.stringify(niz));
                }
                });
            }

            })
        }
    })
  
});

  app.get('/popunivjezbe', function(req, res) {
    
  
    db.vjezba.findAll().then(function(odgovor) {
        if(odgovor==null) {
            var niz=[]; 
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(niz));
        }
       else{ var niz=[];
        for(var i=0; i<odgovor.length; i++) {
        var objekat={id:odgovor[i]["id"],naziv:odgovor[i]["naziv"] ,spirala:odgovor[i]["spirala"]};
        niz.push(objekat);
        }
        res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(niz));
    }
    });
   
});

app.get('/zadaci', function(req, res) {
    var contype = req.headers['accept'];

    if (req.accepts('json')) {
  /*  fs. readFile('postavka.txt', function(err, contents) {
        var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n"); 
        var niz=[];
        for(var i=0; i<redovi.length; i++) {
        var kolona=redovi[i].split(" ");
        var objekat={naziv:kolona[0], postavka:kolona[1]};
        niz.push(objekat);
    }

    res.writeHead(200, {'Content-Type': 'application/json'});

    res.end(JSON.stringify(niz));
    });*/
    db.zadatak.findAll().then(function(odgovor) {
        if(odgovor==null) {
            var niz=[]; 
            res.writeHead(200, {'Content-Type': '/application/json'});
            res.end(JSON.stringify(niz));
        }
       else{ var niz=[];
        for(var i=0; i<odgovor.length; i++) {
        var objekat={naziv:odgovor[i]["naziv"] ,postavka:odgovor[i]["postavka"]};
        niz.push(objekat);
        }
        res.writeHead(200, {'Content-Type': '/application/json'});
        res.end(JSON.stringify(niz));
    }
    });
  }
  else if((!req.accepts('json') && req.accepts('application/xml')) || (!req.accepts('json') && req.accepts('text/xml')) ) {
  /*  fs.readFile('postavka.txt', function(err, contents) {
       
       
    var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n"); 
      
    var xml2 = builder.create('zadaci',{ encoding: 'utf-8' })
    for(var i=0; i<redovi.length; i++) {
        var kolona=redovi[i].split(" ");
      
      xml2.ele('zadatak')
        .ele('naziv',  kolona[0]).up()
        .ele('postavka',  kolona[1]).up()
        
    }

    var xml = xml2.end({pretty: true});
    if(req.accepts('application/xml'))res.writeHead(200, {'Content-Type': 'application/xml'});
    else if( req.accepts('text/xml'))res.writeHead(200, {'Content-Type': 'text/xml'});
    res.end(xml);
});*/
db.zadatak.findAll().then(function(odgovor) {
    if(odgovor.length==0) {
        var niz=""; 
        if(req.accepts('application/xml'))res.writeHead(200, {'Content-Type': 'application/xml'});
        else if( req.accepts('text/xml'))res.writeHead(200, {'Content-Type': 'text/xml'});
        res.end(niz);
    }
    else{
        
        var xml2 = builder.create('zadaci',{ encoding: 'utf-8' })
    
        for(var i=0; i<odgovor.length; i++) { 
      
            xml2.ele('zadatak')
              .ele('naziv',  odgovor[i]["naziv"]).up()
              .ele('postavka',  odgovor[i]["postavka"]).up()
        }
        var xml = xml2.end({pretty: true});
        if(req.accepts('application/xml'))res.writeHead(200, {'Content-Type': 'application/xml'});
        else if( req.accepts('text/xml'))res.writeHead(200, {'Content-Type': 'text/xml'});
        res.end(xml);
    
      

    }

});

  }

  else if(!req.accepts('xml') && req.accepts('csv')) {
   /* fs. readFile('postavka.txt', function(err, contents) {
        var redovi=contents.toString().replace(/\r\n/g,'\n').split("\n"); 
        var niz=[];
        for(var i=0; i<redovi.length; i++) {
        var kolona=redovi[i].split(" ");
        var objekat={naziv:kolona[0], postavka:kolona[1]};
        niz.push(objekat);
    }
    
    var csv = json2csv.parse(niz);
    var csv2=csv.replace(/"/g,'');
    csv2=csv2.substr(16);

    

   res.writeHead(200, {'Content-Type': 'text/csv'});
    res.end(csv2);
    });*/

    db.zadatak.findAll().then(function(odgovor) {
        if(odgovor==null) {
            var niz=[]; 
            res.writeHead(200, {'Content-Type': 'text/csv'});
            res.end(niz);
        }
      else{  var niz=[];
        for(var i=0; i<odgovor.length; i++) { 
            var objekat={naziv:odgovor[i]["naziv"], postavka:odgovor[i]["postavka"]};
            niz.push(objekat);
        }
        if(odgovor.length!=0) {
        var csv = json2csv.parse(niz);
        var csv2=csv.replace(/"/g,'');
         csv2=csv2.substr(16);

        }

   res.writeHead(200, {'Content-Type': 'text/csv'});
    res.end(csv2);
    }

    });
   
  }



  else res.end();
   
 
});

app.post('/addZadatak',function(req, res) {
    var tijelo=req.file;
    var naziv=req.body;
    
    

    var storage = multer.diskStorage(
        {
            destination:function ( req, file, cb ) {
                cb( null, './zadaci');
            }, 
            filename: function ( req, file, cb ) {
                cb( null, req.body.naziv + ".pdf");
            }
        }
    );
    
    var upload = multer( {
        fileFilter: function (req, file, cb) {
            var path='./zadaci/'+req.body.naziv+'.pdf';
            if (file.mimetype !== 'application/pdf' || fs.existsSync(path)) {
              return cb(new Error('Greska'))
            }
          

        
            cb(null, true)
          },
        storage: storage } );

    var uploadfile=upload.single('postavka');

    uploadfile(req, res, function(err){
        if(err) res.redirect('/greska.html')
      else {  var zadaci={"naziv": req.body.naziv,
        "postavka": "http://localhost:8080/zadatak?naziv="+req.body.naziv };
        var json = JSON.stringify(zadaci);
       
    fs.writeFile("./zadaci/"+req.body.naziv+"Zad.json",json,function (err) {
    if (err) throw err;
    });
    db.zadatak.create({naziv: req.body.naziv, postavka : "http://localhost:8080/zadatak?naziv="+req.body.naziv}).then( function(odg) {
        console.log("upisano");
    })
    res.redirect('/addZadatak.html');
}
        });

    
});

app.post('/addVjezba',function(req, res) {
    console.log(req.body);
    var spirala=req.body.spirala;
  if(req.body.naziv!=null) {
    db.vjezba.findOne({where:{naziv:req.body.naziv}}).then(function(nadjeno) {
        if (nadjeno==null) {

      
   if(spirala!=null)  {
     
    db.vjezba.create({naziv: req.body.naziv, spirala: true }).then(function(odgovor) {

        var godinaId = req.body.sGodine;
        var vjezbaId;
        db.vjezba.findOne({where:{naziv:req.body.naziv}}).then(function(odgovori) {
             vjezbaId=odgovori["id"];
        

        db.godina.findOne({where:{nazivGod:godinaId}}).then(function(odgovorg) {
            odgovorg.getVjezbe().then(function(odgovor2) {
                
                if(!odgovor2.find(x=>x.dataValues.id==vjezbaId)) {
                   // console.log(x);
                    odgovorg.addVjezbe(vjezbaId).then(function(odgovor3) {
                      // res.redirect('/addVjezba.html');
                    });
                }
                else //res.redirect('/addVjezba.html');
                console.log("bla");
            });
        });
       //res.redirect('/addVjezba.html');
        console.log("tu")
    });
       }).catch(function(err) {
       
       })

        }
        else {
            db.vjezba.create({naziv: req.body.naziv, spirala: false }).then(function(odgovor) {

                var godinaId = req.body.sGodine;
                var vjezbaId;
                db.vjezba.findOne({where:{naziv:req.body.naziv}}).then(function(odgovori) {
                     vjezbaId=odgovori["id"];
                

                db.godina.findOne({where:{nazivGod:godinaId}}).then(function(odgovorg) {
                    odgovorg.getVjezbe().then(function(odgovor2) {
                        
                        if(!odgovor2.find(x=>x.dataValues.id==vjezbaId)) {
                           // console.log(x);
                            odgovorg.addVjezbe(vjezbaId).then(function(odgovor3) {
                              // res.redirect('/addVjezba.html');
                            });
                        }
                        else //res.redirect('/addVjezba.html');
                        console.log("bla");
                    });
                }).catch(function(err) {});
               //res.redirect('/addVjezba.html');
                console.log("tu")
            });
               }).catch(function(err) {
               
               })

        }
    }
})

        //ovdje
        
    }
    

    else {
        var godinaId = req.body.sGodine;
                var vjezbaId;
               
                db.vjezba.findOne({where:{id:req.body.sVjezbe}}).then(function(odgovori) {
                     vjezbaId=odgovori["id"];
                

                db.godina.findOne({where:{nazivGod:godinaId}}).then(function(odgovorg) {
                    odgovorg.getVjezbe().then(function(odgovor2) {
                        
                        if(!odgovor2.find(x=>x.dataValues.id==vjezbaId)) {
                           // console.log(x);
                            odgovorg.addVjezbe(vjezbaId).then(function(odgovor3) {
                              // res.redirect('/addVjezba.html');
                            });
                        }
                        else //res.redirect('/addVjezba.html');
                        console.log("bla");
                    });
                });
               //res.redirect('/addVjezba.html');
                console.log("tu")
            }).catch(function(err) {});
    }
    res.redirect('/addVjezba.html');
    });

app.post('/vjezba/:idVjezbe/zadatak',function(req,res) {
    var zadatakId = req.body.sZadatak;
    var vjezbaId=req.body.sVjezbe;
    console.log(req.body);

    db.zadatak.findOne({where:{naziv:req.body.sZadatak}}).then(function(odgovori) {
         zadatakId=odgovori["id"];
    

    db.vjezba.findOne({where:{id:req.body.sVjezbe}}).then(function(odgovorg) {
        odgovorg.getZadaci().then(function(odgovor2) {
            
            if(!odgovor2.find(x=>x.dataValues.id==zadatakId)) {
               // console.log(x);
                odgovorg.addZadaci(zadatakId).then(function(odgovor3) {
                  // res.redirect('/addVjezba.html');
                });
            }
            else //res.redirect('/addVjezba.html');
            console.log("bla");
        });
    });
   //res.redirect('/addVjezba.html');
    console.log("tu")
}).catch(function(err) {});

   res.redirect('/addVjezba.html');
 // res.end();
 
});

app.post('/student', function(req,res) {
    console.log(req.body.godina)
   
   // console.log(req.body.studenti[0].index)
 /*  db.godina.findOne({where:{id:req.body.godina}}).then(function(gododg) {
   
    
       
    db.student.findOne({where:{index:req.body.studenti[1].index}}).then(function(odgic) {
       
        if(odgic!=null) {

            gododg.addStudenti(odgic["id"])  
            
       
    }
    else {
      console.log(req.body.studenti.length)
        var i=0;
        while(i<req.body.studenti.length) {
    db.student.create({imePrezime:req.body.studenti[i].imePrezime,index:req.body.studenti[i].index,studentGod:req.body.godina}).then(function(odg3) {
       
      
        i++;
      
        db.student.create({imePrezime:req.body.studenti[i].imePrezime,index:req.body.studenti[i].index,studentGod:req.body.godina}).then(function(odg5) {

        })
        console.log(i)
        
    })
}
    }
    
    })



})*/
var n=0;
var m=0;
var autoriListaPromisea=[];
db.godina.findOne({where:{id:req.body.godina}}).then(function(gododg) {
    
    var i=0;
while(i<req.body.studenti.length){
  
    if(i>=req.body.studenti.length)break;
    db.student.findOne({where:{index:req.body.studenti[i].index}}).then(function(odg2){
        if(odg2!=null)
        {
           // m=m-1;
          //  console.log("godina")
         
            if(odg2["studentGod"]==null)
            {
                gododg.addStudenti(odg2["id"]);
               // console.log("godina")
                m++;
               
            }
        }

        
        
    }).catch(function(err) {
        
    })
i++;
}
})


for(var i=0; i<req.body.studenti.length; i++) {

   
    autoriListaPromisea.push( 
        
       db.student.create({imePrezime:req.body.studenti[i].imePrezime,index:req.body.studenti[i].index,studentGod:req.body.godina}).then(function(studenti) {
        n++;
        m++;
       
        }).catch(function(err) {
          
       })
     
        );
       
 }

Promise.all(autoriListaPromisea).then(function(autori){
    
    db.godina.findOne({where:{id:req.body.godina}}).then(function(tagodina) {
        if(tagodina!=null) {
        console.log(tagodina["nazivGod"])
        res.writeHead(200,{'Content-Type':'application/json'});
        res.end(JSON.stringify({message:"Dodano je "+ n+" novih studenata i upisano "+ m+" na godinu "+ tagodina["nazivGod"]}))
        }
    })
   
}).catch(function(err) {

})



//db.student.create({imePrezime:"Selma Lekic",index:"17698",studentGod:"3"}).then(function(odg5) {

//})
});
app.use(express.static('public')); 
app.listen(8080);