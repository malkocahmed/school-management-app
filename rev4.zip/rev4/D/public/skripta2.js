function treca() {
    var ajax = new XMLHttpRequest();
    var selekt = document.getElementsByName("sVjezbe")[0];
    var selekt1=document.getElementsByName("sVjezbe")[1];
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
            var nizZadaci = JSON.parse(ajax.responseText);

            for(var i=0; i<nizZadaci.length; i++) {
                var option = document.createElement("option");
                option.value =  nizZadaci[i].id; 
                option.text =  nizZadaci[i].naziv;          
                selekt.add(option);
              
            }
            var nizZadaci2 = JSON.parse(ajax.responseText);

            for(var i=0; i<nizZadaci2.length; i++) {
                var option1 = document.createElement("option");
                option1.value =  nizZadaci2[i].id; 
                option1.text =  nizZadaci2[i].naziv;                 
                selekt1.add(option1);
               
            }

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
   
    ajax.open('GET', 'http://localhost:8080/popunivjezbe', true);
    ajax.send();
}