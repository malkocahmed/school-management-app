var GodineAjax = (function(){
    var konstruktor = function(divSadrzaj){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
         
            if (this.readyState == 4 && this.status == 200) {
              var json=JSON.parse(xhttp.responseText);
              
            for(var i=0; i<json.length; i++) {  
              var para = document.createElement("DIV");
              para.setAttribute("class", "godina");                     
            var t = document.createElement("P");    
            var x=document.createTextNode(json[i].nazivGod+"\n"+json[i].nazivRepVje+"\n"+json[i].nazivRepSpi);
            t.appendChild(x);
            para.appendChild(t); 
            divSadrzaj.appendChild(para);
             
            }
        
        };
    }
        xhttp.open("GET", "http://localhost:8080/godine", true);
        xhttp.send();
        return {
            osvjezi:function(){
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) divSadrzaj=this.responseText;
            }
        }
        }
    }
   
    return konstruktor;
    
}());
 

