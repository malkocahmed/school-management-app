function ajax() {
    var ajax = new XMLHttpRequest();
    
    var selekt = document.getElementsByName("sGodina")[0];
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) { 
            var nizGodine = JSON.parse(ajax.responseText);

            for(var i=0; i<nizGodine.length; i++) {
                var option = document.createElement("option");
                option.value = option.text = nizGodine[i].nazivGod;               
                selekt.add(option);
              
            }
           

        }
        if(ajax.readyState == 4 && ajax.status == 404) {
            document.write = "Greska";
        }
    }
 

    ajax.open('POST', 'http://localhost:8080/student', true);
    ajax.send();
}